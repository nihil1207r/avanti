import { useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import frames from "@/assets/pizzaFrames";

const TOTAL_FRAMES = frames.length;

export function PizzaScrollAnimation() {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"],
  });

  const frameIndex = useTransform(scrollYProgress, [0, 1], [0, TOTAL_FRAMES - 1]);

  // Preload all frames into Image objects once
  useEffect(() => {
    const images = frames.map((src) => {
      const img = new Image();
      img.src = src;
      return img;
    });
    imagesRef.current = images;

    // Draw first frame immediately
    const first = images[0];
    const draw = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.width = first.naturalWidth || 854;
      canvas.height = first.naturalHeight || 480;
      canvas.getContext("2d")?.drawImage(first, 0, 0);
    };
    if (first.complete) draw();
    else first.onload = draw;
  }, []);

  // Update canvas on scroll
  useEffect(() => {
    return frameIndex.on("change", (v) => {
      const idx = Math.round(Math.max(0, Math.min(TOTAL_FRAMES - 1, v)));
      const img = imagesRef.current[idx];
      const canvas = canvasRef.current;
      if (!img?.complete || !canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);
    });
  }, [frameIndex]);

  return (
    <div ref={containerRef} className="relative" style={{ height: `${TOTAL_FRAMES * 4}px` }}>
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-black flex items-center justify-center">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          style={{ objectFit: "cover" }}
        />

        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/70 z-10" />

        <motion.div
          className="relative z-20 text-center text-white px-6 flex flex-col items-center"
          style={{
            opacity: useTransform(scrollYProgress, [0, 0.05, 0.25, 0.35], [1, 1, 1, 0]),
            y: useTransform(scrollYProgress, [0, 0.35], ["0%", "-8%"]),
          }}
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 backdrop-blur px-4 py-1.5 text-xs uppercase tracking-[0.2em] text-accent"
          >
            <span className="size-1.5 rounded-full bg-accent animate-pulse" />
            Botoșani · România
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35 }}
            className="max-w-4xl font-display text-5xl font-bold leading-[1.05] sm:text-6xl md:text-7xl lg:text-[5.5rem]"
          >
            {t("hero.title")}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.55 }}
            className="mt-6 max-w-xl text-lg text-white/85 sm:text-xl"
          >
            {t("hero.subtitle")}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.75 }}
            className="mt-10 flex flex-wrap gap-3 justify-center"
          >
            <Button asChild size="lg" className="bg-primary hover:bg-primary-glow shadow-warm text-base h-14 px-8">
              <Link to="/meniu">{t("hero.cta")} <ArrowRight className="ml-1" /></Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-14 px-8 text-base bg-transparent border-white/40 text-white hover:bg-white hover:text-foreground">
              <Link to="/contact">{t("hero.cta2")}</Link>
            </Button>
          </motion.div>
        </motion.div>

        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 text-white/60"
          style={{ opacity: useTransform(scrollYProgress, [0, 0.08], [1, 0]) }}
        >
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <div className="w-px h-10 bg-white/30 animate-pulse" />
        </motion.div>
      </div>
    </div>
  );
}
