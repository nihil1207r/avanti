import { Helmet } from "react-helmet-async";
import { useTranslation } from "react-i18next";

type Props = {
  title: string;
  description: string;
  path?: string;
  jsonLd?: object;
};

export function Seo({ title, description, path = "/", jsonLd }: Props) {
  const { i18n } = useTranslation();
  const lang = i18n.language.startsWith("en") ? "en" : "ro";
  const url = typeof window !== "undefined" ? window.location.origin + path : path;
  return (
    <Helmet>
      <html lang={lang} />
      <title>{title}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content="website" />
      <meta property="og:url" content={url} />
      <meta name="twitter:card" content="summary_large_image" />
      {jsonLd && <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>}
    </Helmet>
  );
}
